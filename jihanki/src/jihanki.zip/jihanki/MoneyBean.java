package jihanki;

public class MoneyBean {
	String MoneyName = null;
	int count = 0;

	public String getMoneyName() {
		return MoneyName;
	}
	public void setMoneyName(String moneyName) {
		MoneyName = moneyName;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}

}
