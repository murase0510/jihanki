package jihanki;

public class MainClass {
	public static void main(String args[]) {
		JihankiAction ja = new JihankiAction();
		ja.waitForAction();
	}
}
